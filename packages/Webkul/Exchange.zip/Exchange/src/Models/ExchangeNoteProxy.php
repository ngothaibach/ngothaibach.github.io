<?php

namespace Webkul\Exchange\Models;

use Konekt\Concord\Proxies\ModelProxy;

class ExchangeNoteProxy extends ModelProxy
{

}