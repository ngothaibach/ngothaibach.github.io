<?php

namespace Webkul\Exchange\Contracts;

interface ProductExchangeNote
{
}