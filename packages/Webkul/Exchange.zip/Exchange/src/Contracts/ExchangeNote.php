<?php

namespace Webkul\Exchange\Contracts;

interface ExchangeNote
{
}