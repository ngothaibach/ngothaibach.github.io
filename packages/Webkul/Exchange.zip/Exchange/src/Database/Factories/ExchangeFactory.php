<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */
use Faker\Generator as Faker;
use Webkul\Exchange\Models\ExchangeNote;

$factory->define(ExchangeNote::class, function (Faker $faker) {
    //
});