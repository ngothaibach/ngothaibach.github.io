@extends('shop::layouts.master')

@section('page_title')
    Package Exchange
@stop

@section('content-wrapper')

    <div class="main">
        Package Exchange
    </div>

@stop