<?php

return [
    [
        'key' => 'exchange',
        'name' => 'Exchange',
        'route' => 'exchange.admin.index',
        'sort' => 2
    ]
];